package com.example.project

class Task {
    var id : Int ?= null
    var name : String ?= null
    var priority : String ?= null
    var description : String ?= null
    var progress : String ?= null
    var due_date : String ?= null
    var assignee : String ?= null
    var report_to : String ?= null
    var safe_delete : Boolean ?= null
}